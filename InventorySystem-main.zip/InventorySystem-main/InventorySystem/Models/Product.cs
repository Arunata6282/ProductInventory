﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace InventorySystem.Models
{
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string ProductCode { get; set; }

        [Required, MaxLength(200)]
        public string ProductName { get; set; }

        public byte[] ProductImage { get; set; }
        public DateTimeOffset CreatedDate { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset UpdatedDate { get; set; } = DateTimeOffset.UtcNow;

        [ForeignKey("User")]
        public Guid CreatedUser { get; set; }

        public bool IsFavourite { get; set; }
        public bool Active { get; set; }

        [MaxLength(100)]
        public string HSNCode { get; set; }

        public decimal TotalStock { get; set; }

        public ICollection<ProductVariant> Variants { get; set; }
    }
}
