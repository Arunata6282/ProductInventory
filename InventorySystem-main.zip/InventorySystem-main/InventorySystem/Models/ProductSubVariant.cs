﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace InventorySystem.Models
{
    public class ProductSubVariant
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Option { get; set; }

        [ForeignKey("ProductVariant")]
        public int VariantId { get; set; }

        public ProductVariant Variant { get; set; }
        public decimal Stock { get; set; }
    }

}
