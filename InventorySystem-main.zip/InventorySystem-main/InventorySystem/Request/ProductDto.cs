﻿namespace InventorySystem.Request
{
    public class ProductDto
    {
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ProductImageBase64 { get; set; }
        public Guid CreatedUser { get; set; }
        public bool IsFavourite { get; set; }
        public bool Active { get; set; }
        public string HSNCode { get; set; }
        public decimal TotalStock { get; set; }
        public List<ProductVariantDto> Variants { get; set; }
    }

    public class ProductVariantDto
    {
        public string Name { get; set; }
        public List<ProductSubVariantDto> SubVariants { get; set; }
    }

    public class ProductSubVariantDto
    {
        public string Option { get; set; }
        public decimal Stock { get; set; }
    }

}
