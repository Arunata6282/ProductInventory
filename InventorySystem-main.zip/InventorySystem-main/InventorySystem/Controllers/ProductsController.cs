﻿using InventorySystem.Models;
using InventorySystem.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InventorySystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Create Product
        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] ProductDto productDto)
        {
            if (productDto == null)
                return BadRequest("Invalid product data.");

            // Convert Base64 to byte[]
            byte[] imageBytes = null;
            if (!string.IsNullOrEmpty(productDto.ProductImageBase64))
            {
                try
                {
                    imageBytes = Convert.FromBase64String(productDto.ProductImageBase64);
                }
                catch (FormatException)
                {
                    return BadRequest("Invalid Base64 string for product image.");
                }
            }

            // Create Product entity
            var product = new Product
            {
                ProductCode = productDto.ProductCode,
                ProductName = productDto.ProductName,
                ProductImage = imageBytes,
                CreatedDate = DateTimeOffset.UtcNow,
                UpdatedDate = DateTimeOffset.UtcNow,
                CreatedUser = productDto.CreatedUser,
                IsFavourite = productDto.IsFavourite,
                Active = productDto.Active,
                HSNCode = productDto.HSNCode,
                TotalStock = productDto.TotalStock,
                Variants = productDto.Variants.Select(v => new ProductVariant
                {
                    Name = v.Name,
                    SubVariants = v.SubVariants.Select(sv => new ProductSubVariant
                    {
                        Option = sv.Option,
                        Stock = sv.Stock
                    }).ToList()
                }).ToList()
            };

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
        }


        // List Products
        [HttpGet]
        public async Task<IActionResult> ListProducts()
        {
            var products = await _context.Products.Include(p => p.Variants).ThenInclude(v => v.SubVariants).ToListAsync();
            return Ok(products);
        }

        // Get Product by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _context.Products.Include(p => p.Variants).ThenInclude(v => v.SubVariants).FirstOrDefaultAsync(p => p.Id == id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

        // Add Stock
        [HttpPost("{productId}/add-stock")]
        public async Task<IActionResult> AddStock(Guid productId, [FromBody] decimal quantity)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null)
                return NotFound();

            product.TotalStock += quantity;
            await _context.SaveChangesAsync();

            return Ok(product);
        }

        // Remove Stock
        [HttpPost("{productId}/remove-stock")]
        public async Task<IActionResult> RemoveStock(Guid productId, [FromBody] decimal quantity)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null)
                return NotFound();

            if (product.TotalStock < quantity)
                return BadRequest("Not enough stock available.");

            product.TotalStock -= quantity;
            await _context.SaveChangesAsync();

            return Ok(product);
        }
    }

}
